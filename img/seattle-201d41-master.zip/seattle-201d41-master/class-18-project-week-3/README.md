# Class 18 - Project Week: Milestone 3

## Development
1. Start with a meeting to assess how the previous day went, and then plan today's tasks accordingly.

2. Your goal today: MVP. You want to have everything working, all of your core features in place, and bugs worked out. Once you have reached MVP for your HTML and JS, you can focus on the CSS. That will leave the next work day for stretch goals and focusing on getting the look and feel dialed in to exactly what you want.

Keep in mind that as we get closer to final presentation day, it's never too soon to start thinking about presentations, and you're encouraged to test your project on one of the projectors in the classroom spaces at some point today. It just makes everything a little different to be viewed that way. We'll share some specific strategies in a presentation prep document.
