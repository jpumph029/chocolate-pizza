var number = 25;

console.log(number)

hello this will throw an eslint console.error;




