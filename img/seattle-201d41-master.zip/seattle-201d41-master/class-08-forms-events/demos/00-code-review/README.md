# 06-cookiestand
Salmon Cookies Lab Project

Used class demo code for this lab to create my initial objects without constructors
